import { ListecustomersDirective } from './listecustomers.directive';

describe('ListecustomersDirective', () => {
  it('should create an instance', () => {
    const directive = new ListecustomersDirective();
    expect(directive).toBeTruthy();
  });
});
