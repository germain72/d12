export class Customers {
  public id !: number;
  public name !: string;
  public societe !: string;
  public dateCreation : Date = new Date();
}
